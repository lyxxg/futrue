<?php

namespace App\Http\Controllers\Tools;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class blblController extends Controller
{
    public function blblview(){
     return view("tools.blbl");
    }

}
