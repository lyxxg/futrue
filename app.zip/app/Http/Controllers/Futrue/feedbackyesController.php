<?php

namespace App\Http\Controllers\Futrue;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class feedbackyesController extends Controller
{
    //
}
