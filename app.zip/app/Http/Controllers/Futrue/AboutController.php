<?php

namespace App\Http\Controllers\Futrue;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AboutController extends Controller
{
    public function about(){
        return view("Futrue.about");
    }
}
