<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Answergoodandbad extends Model
{
    public $timestamps = false;


}
