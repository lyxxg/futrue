@extends('Futrue.layouts.app')
@section("content")
    <div class="post-foot well" style="text-align:center;">
        <!-- Social media icons -->
        <h2 >扫码关注</h2>
        <img src="{{asset('futrue/img/tools/wechat.jpg')}}" style="">
        <hr/>
<div >
    网站公众号:<span style="color: red;font-size: 30px;font-family: '楷体';
font-style: oblique;
font-weight: bold;">黑客美学</span>
    <p></p>
</div>
</div> <!-- Name -->

@endsection("content")
