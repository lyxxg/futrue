<!-- Mainbar ends -->
<div class="clearfix"></div>
<!-- Foot starts -->
<div class="foot">
    <div class="bor"></div>
    <div class="container-fluid">
        <div class="row-fluid">

            <div class="span4">
                <div class="fwidget">

                    <div class="col-l">
                        <h6>下载</h6>
                        <ul>
                            <li><a href="https://www.baidu.com/link?url=5EvsZWB7waIiZiIMrbWV2fWpfIZVGVJuXKhSQ-mk0mvoknpBE5saPvN6cJCLbkv348upeiPXXTUPmjXRZMVKx_dHnv7Onq8COyJVnrR3g47&amp;wd=&amp;eqid=95e30e510004a594000000065ad884df">mysql</a></li>
                            <li><a href="#">暂无</a></li>
                            <li><a href="#">暂无</a></li>
                            <li><a href="#">暂无</a></li>
                            <li><a href="#">暂无</a></li>
                        </ul>
                    </div>

                    <div class="col-r">
                        <h6>友情链接</h6>
                        <ul>
                            <li><a href="http://www.noxue.com/" target="_blank">不学网</a></li>
                            <li><a href="http://www.hooos.com/" target="_blank">虎窝网</a></li>
                            <li><a href="http://phpfen.com/" target="_blank">php粉</a></li>
                            <li><a href="#">暂无</a></li>
                            <li><a href="#">暂无</a></li>
                        </ul>
                    </div>

                    <div class="clearfix"></div>

                </div>
            </div>

            <div class="span4">
                <div class="fwidget">

                    <div class="col-l">
                        <h6>工具</h6>
                        <ul>
                            <li><a href="{{route('blbl')}}">b站封面获取</a></li>
                            <li><a href="#">端口扫描</a></li>
                            <li><a href="#">暂无</a></li>
                            <li><a href="#">暂无</a></li>
                            <li><a href="#">暂无</a></li>
                        </ul>
                    </div>

                    <div class="col-r">
                        <h6>关于</h6>
                        <ul>
                            <li><a href="{{route('wechatpublic')}}">公众号</a></li>
                            <li><a href="#">暂无</a></li>
                            <li><a href="{{route('contactme')}}">联系我</a></li>
                            <li><a href="#">暂无</a></li>
                            <li><a href="#">暂无</a></li>
                        </ul>
                    </div>

                    <div class="clearfix"></div>

                </div>
            </div>



        <div class="row-fluid">
            <div class="span12">
                <hr class="visible-desktop">
                <div class="copy">Copyright 2018 &copy; -未来笔记</div>
            </div>
        </div>

    </div>
</div>
<!-- Foot ends -->

</div>

<div class="clearfix"></div>

<!-- Main content ends -->


<!-- Scroll to top -->
<script
        src="http://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
        crossorigin="anonymous"></script>
<span class="totop"><a href="#"><i class="icon-chevron-up"></i></a></span>
<script src="{{asset('futrue/js/futruetheme.js')}}"></script>
<script src="{{asset('futrue/js/avatar.js')}}"></script>
