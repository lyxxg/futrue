@extends('Futrue.layouts.app')
@section("content")
    <div class="page-title">
        <h2>关于<span>未来笔记</span></h2>
    </div>
    <div class="post-foot well">
    此博客正处于测试阶段
    </div>
@endsection("content")