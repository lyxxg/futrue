@extends('futrue.layouts.app')
@section("content")
    <div class="page-title">
        <h2>404
            <span>页面不存在</span>
        </h2>
    </div>
    <hr/>
<img src="{{asset('/futrue/img/ico/404.jpg')}}">
<hr/>

@endsection("content")